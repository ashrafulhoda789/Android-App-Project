package com.example.zoomcontrol

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ZoomControls
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var imageView: ImageView
    private lateinit var zoomControls: ZoomControls
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        imageView = findViewById(R.id.imageId)
        zoomControls = findViewById(R.id.zoomId)

        zoomControls.setOnZoomInClickListener {
            imageView.scaleX *= 1.2f
            imageView.scaleY *= 1.2f
        }

        zoomControls.setOnZoomOutClickListener{

            val currentScaleX = imageView.scaleX
            val currentScaleY = imageView.scaleY

            if(currentScaleX>1f && currentScaleY>1f){
                imageView.scaleX *= 0.8f
                imageView.scaleY *= 0.8f
            }

        }

    }
}