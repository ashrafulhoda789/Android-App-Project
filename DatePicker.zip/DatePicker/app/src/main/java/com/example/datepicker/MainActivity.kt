package com.example.datepicker

import android.annotation.SuppressLint
import android.icu.util.Calendar
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val textView = findViewById<TextView>(R.id.dateText)
        val button = findViewById<Button>(R.id.selectDate)
        val datePicker = findViewById<DatePicker>(R.id.datePickerId)

        textView.text = "Current Date: ${currentDate()}"

        button.setOnClickListener {
            val day = datePicker.dayOfMonth
            val month = datePicker.month
            val year = datePicker.year

            val calendar = Calendar.getInstance()
            calendar.set(year,month,day)

            val dateFormat = SimpleDateFormat("dd / MMM / yyyy", Locale.getDefault())
            textView.text = "Selected Date: ${dateFormat.format(calendar.time)}"
        }
    }

    private fun currentDate(): String {
        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("dd / MMM / yyyy", Locale.getDefault())
        return dateFormat.format(calendar.time)
    }
}