package com.example.implicitandexplicitintent

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        //Explicit intent
        val btn_go = findViewById<Button>(R.id.goButton)
        val text_go = findViewById<TextView>(R.id.textView1)
        btn_go.setOnClickListener {
            val intent = Intent(this,MainActivity2::class.java)
            val data = text_go.text.toString()
            intent.putExtra("name",data)
            startActivity(intent)
            finish()
        }

        //Implicit Intent

        val share = findViewById<Button>(R.id.ShareButton)
        val call = findViewById<Button>(R.id.callButton)

        share.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com"))
            val chooser = Intent.createChooser(intent,"Choose One")
            startActivity(chooser)
        }

        call.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:01576639465"))
            val chooser = Intent.createChooser(intent,"Choose One")
            startActivity(chooser)
        }






        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}