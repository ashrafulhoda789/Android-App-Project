package com.example.videoview

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var videoView: VideoView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        videoView = findViewById(R.id.videoViewId)

        try{
            val uri = Uri.parse("android.resource://" + packageName + "/" + R.raw.song)

            videoView.setVideoURI(uri)

            val mediaController = MediaController(this)
            mediaController.setAnchorView(videoView)
            mediaController.setMediaPlayer(videoView)
            videoView.setMediaController(mediaController)

            videoView.setOnPreparedListener {
                Log.d("VideoView", "Video prepared and starting playback.")
                videoView.start()
            }

            videoView.setOnErrorListener { _, what, extra ->
                Log.e("VideoView", "Error occurred while playing video. What: $what, Extra: $extra")
                true
            }
        }catch(e: Exception){
            Log.e("VideoView", "Exception while setting video URI", e)
        }
    }
}