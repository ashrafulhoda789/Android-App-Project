package com.example.recylerview

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recylerview.adapter.MyAdapter
import com.example.recylerview.model.User

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val layoutManager = LinearLayoutManager(this)

        recyclerView.layoutManager = layoutManager

        val userDataList = DummyData()
        val adapter = MyAdapter(this,userDataList)
        recyclerView.adapter = adapter


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun DummyData(): List<User> {
        val userList = mutableListOf<User>()
        userList.add(User("Jamshed",R.drawable.man,"01576639465"))
        userList.add(User("Kamrul",R.drawable.man1,"01676639465"))
        userList.add(User("Rabi",R.drawable.man2,"01376639465"))
        userList.add(User("Mumir",R.drawable.woman,"01676639465"))
        userList.add(User("Ripa",R.drawable.woman1,"01476639465"))
        userList.add(User("Pipa",R.drawable.woman2,"01876639465"))
        userList.add(User("Mina",R.drawable.woman3,"01976639465"))
        userList.add(User("Tina",R.drawable.woman4,"01776639465"))

        return userList
    }
}


