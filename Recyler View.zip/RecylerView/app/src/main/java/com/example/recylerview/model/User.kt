package com.example.recylerview.model

data class User(val userName: String,val userProfile:Int, val userContact: String)
