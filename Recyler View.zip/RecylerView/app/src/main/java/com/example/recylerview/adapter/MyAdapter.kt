package com.example.recylerview.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater.*
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recylerview.R
import com.example.recylerview.contactActivity
import com.example.recylerview.model.User

class MyAdapter(private val context: Context, private val userData: List<User>) : RecyclerView.Adapter<MyAdapter.listViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter.listViewHolder {
        return listViewHolder(from(parent.context).inflate(R.layout.recycler_item,parent,false))
    }

    override fun getItemCount(): Int = userData.size

    override fun onBindViewHolder(holder: MyAdapter.listViewHolder, position: Int) {
        holder.bind(userData[position])

        holder.itemView.setOnClickListener {
            val intent = Intent(context,contactActivity::class.java)
            intent.putExtra("Image",userData[position].userProfile)
            intent.putExtra("name",userData[position].userName)
            intent.putExtra("contact",userData[position].userContact)

            context.startActivity(intent)
        }
    }

    class listViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        fun bind(user: User) {
            val profileImage = itemView.findViewById<ImageView>(R.id.profile)
            val name = itemView.findViewById<TextView>(R.id.name)
            val contact = itemView.findViewById<TextView>(R.id.phone)

            profileImage.setImageResource(user.userProfile)
            name.text = user.userName
            contact.text = user.userContact
        }

    }
}