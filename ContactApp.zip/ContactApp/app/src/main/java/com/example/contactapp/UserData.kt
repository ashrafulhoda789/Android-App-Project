package com.example.contactapp

data class UserData(var contactProfile: Int, var contactName: String, val contactNumber: String)
