package com.example.contactapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var userArrayList: ArrayList<UserData>
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val contactProfileImage = intArrayOf(
            R.drawable.man,
            R.drawable.man1,
            R.drawable.man2,
            R.drawable.woman,
            R.drawable.woman1,
            R.drawable.woman2,
            R.drawable.woman3,
            R.drawable.woman4
        )

        val contactName = arrayOf(
            "Jamshed","Kamrul","Rabi","Mumir","Ripa","Pipa","Mina","Tina"
        )

        val contactNumber = arrayOf(
            "01576639465",
            "01818284738",
            "01543578346",
            "01867725011",
            "01824687345",
            "01724758347",
            "01724758347",
            "01724758347",
        )

        userArrayList = ArrayList()
        for(position in contactName.indices) {
            val contact = UserData(contactProfileImage[position],contactName[position],contactNumber[position])

            userArrayList.add(contact)
        }
        

        val listView = findViewById<ListView>(R.id.listView)
        listView.adapter = ContactAdapter(this,userArrayList)


        listView.isClickable = true
        listView.setOnItemClickListener { parent, view, position, id ->
            val profile = contactProfileImage[position]
            val name = contactName[position]
            val number = contactNumber[position]
            val intent = Intent(this,DetailContact::class.java)
            intent.putExtra("image",profile)
            intent.putExtra("name",name)
            intent.putExtra("number",number)
            startActivity(intent)
        }




























/*
        val contactList = listOf(
            contactModel(R.drawable.man,"Jamshed"),
            contactModel(R.drawable.man1,"Kamrul"),
            contactModel(R.drawable.man2,"Rabi"),
            contactModel(R.drawable.woman,"Mumir"),
            contactModel(R.drawable.woman1,"Ripa"),
            contactModel(R.drawable.woman2,"Pipa"),
            contactModel(R.drawable.woman3,"Mina"),
            contactModel(R.drawable.woman4,"Tina")


        )
        val contactName = contactList.map {it.name}
        val listView: ListView = findViewById(R.id.listView)
        val adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,contactName)
        listView.adapter = adapter


 */




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}

//data class contactModel(val image: Int, val name: String)