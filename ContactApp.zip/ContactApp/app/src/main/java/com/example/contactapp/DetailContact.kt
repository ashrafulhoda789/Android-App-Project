package com.example.contactapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DetailContact : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detail_contact)

        val userProfile = findViewById<ImageView>(R.id.userImageView)
        val userName = findViewById<TextView>(R.id.UserName)
        val userContactNumber = findViewById<TextView>(R.id.contactNumber)

        val profile = intent.getIntExtra("image",R.drawable.man)
        val name = intent.getStringExtra("name")
        val number = intent.getStringExtra("number")

        userProfile.setImageResource(profile)
        userName.text = name
        userContactNumber.text = number


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}