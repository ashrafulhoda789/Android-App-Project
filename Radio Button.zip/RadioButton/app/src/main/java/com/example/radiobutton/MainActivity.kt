package com.example.radiobutton

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val radioGroup = findViewById<RadioGroup>(R.id.radioGroupId)
        val showButton = findViewById<Button>(R.id.showButton)
        val textView = findViewById<TextView>(R.id.showText)

        showButton.setOnClickListener {
            val selectedId = radioGroup.checkedRadioButtonId

           if(selectedId != -1){
               val genderButton = findViewById<RadioButton>(selectedId)
               textView.text = "You have selected: ${genderButton.text}"
           }else
           {
               textView.text = "No button is selected"
           }
        }
    }
}