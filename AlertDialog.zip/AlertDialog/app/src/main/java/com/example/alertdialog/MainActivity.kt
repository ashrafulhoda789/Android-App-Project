package com.example.alertdialog

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(),View.OnClickListener {

    private lateinit var exitButton: Button
    private lateinit var alertDialog: AlertDialog.Builder
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        exitButton = findViewById(R.id.buttonId)
        exitButton.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        alertDialog = AlertDialog.Builder(this)

        //for title
        alertDialog.setTitle(R.string.title_text)

        //for message
        alertDialog.setMessage(R.string.message_text)

        //for icon
        alertDialog.setIcon(R.drawable.alert)

        alertDialog.setCancelable(false)

        alertDialog.setPositiveButton(android.R.string.ok){ dialog, which ->
            finish()
        }

        alertDialog.setNegativeButton(android.R.string.cancel){ dialog, which ->
            dialog.cancel()
            Toast.makeText(this,"You've clicked negative button",Toast.LENGTH_SHORT).show()
        }

        alertDialog.show()


    }
}


